/*!
 * \file ctr_drbg.h
 * \brief CTR-DRBG �˰��� ���� (NIST 800-90)
 * \author
 * Copyright (c) 2011 by \<KISA\>
 */

#ifndef CTR_DRBG_H
#define CTR_DRBG_H

#include <jni.h>

#ifdef  __cplusplus
extern "C" {
#endif

//------------------------------------------------
#define ALGO_SEED								1
#define ALGO_ARIA128							2
#define ALGO_ARIA192							3
#define ALGO_ARIA256							4

//------------------------------------------------
#define ALGO_SEED_OUTLEN_IN_BYTES				16
#define ALGO_ARIA128_OUTLEN_IN_BYTES			16
#define ALGO_ARIA192_OUTLEN_IN_BYTES			16
#define ALGO_ARIA256_OUTLEN_IN_BYTES			16

//------------------------------------------------
#define ALGO_SEED_KEYLEN_IN_BYTES				16
#define ALGO_ARIA128_KEYLEN_IN_BYTES			16
#define ALGO_ARIA192_KEYLEN_IN_BYTES			24
#define ALGO_ARIA256_KEYLEN_IN_BYTES			32

//------------------------------------------------
#define ALGO_SEED_SECURITY_STRENGTH_IN_BYTES	16
#define ALGO_ARIA128_SECURITY_STRENGTH_IN_BYTES	16
#define ALGO_ARIA192_SECURITY_STRENGTH_IN_BYTES	24
#define ALGO_ARIA256_SECURITY_STRENGTH_IN_BYTES	32

//------------------------------------------------
#define ALGO_SEED_SEEDLEN_IN_BYTES				ALGO_SEED_OUTLEN_IN_BYTES + ALGO_SEED_KEYLEN_IN_BYTES
#define ALGO_ARIA128_SEEDLEN_IN_BYTES			ALGO_ARIA128_OUTLEN_IN_BYTES + ALGO_ARIA128_KEYLEN_IN_BYTES
#define ALGO_ARIA192_SEEDLEN_IN_BYTES			ALGO_ARIA192_OUTLEN_IN_BYTES + ALGO_ARIA192_KEYLEN_IN_BYTES
#define ALGO_ARIA256_SEEDLEN_IN_BYTES			ALGO_ARIA256_OUTLEN_IN_BYTES + ALGO_ARIA256_KEYLEN_IN_BYTES

//------------------------------------------------
#define MAX_V_LEN_IN_BYTES						16
#define MAX_Key_LEN_IN_BYTES					32
#define MAX_SEEDLEN_IN_BYTES					ALGO_ARIA256_SEEDLEN_IN_BYTES

//------------------------------------------------
#define MIN_ENTROPY_INPUT_LEN_IN_BYTES			// Depends on SECURITY_STRENGTH of each algorithm

//------------------------------------------------
#define MAX_NUM_INPUT_OF_BYTES_PER_REQUEST		0x10000			// 2^19 bits

//------------------------------------------------
// The following values are too huge to apply on the current architectures,
// thus we do not consider the maximum length of either input or entropy.
#define MAX_ENTROPY_INPUT_LEN_IN_BYTES			0x100000000		// 2^35 bits
#define MAX_PERSONALIZED_STRING_LEN_IN_BYTES	0x100000000		// 2^35 bits
#define MAX_ADDITIONAL_INPUT_LEN_IN_BYTES		0x100000000		// 2^35 bits
#define NUM_OF_REQUESTS_BETWEEN_RESEEDS			0x200000000000UL// 2^48 bits

#define STATE_INITIALIZED_FLAG					0xFE12DC34

//------------------------------------------------
// The following values define either using derivation-function or not
// when KISA_CTR_DRBG_Instantiate(..., unsigned char derivation_function_flag) is called.
#define NON_DERIVATION_FUNCTION					0x00
#define USE_DERIVATION_FUNCTION					0xFF

typedef unsigned long long	uint64;

JNIEXPORT void JNICALL Java_kr_or_kisa_seed_ctrdrbg_CTRDRBG_ctrIncrease(JNIEnv* env, jobject thiz, jbyteArray Counter);
JNIEXPORT jint JNICALL Java_kr_or_kisa_seed_ctrdrbg_CTRDRBG_blockCipherDf(JNIEnv* env, jobject thiz, jbyte algo, jbyteArray inputString, jint input_str_len, jbyteArray Output, jint outlen);
JNIEXPORT jint JNICALL Java_kr_or_kisa_seed_ctrdrbg_CTRDRBG_update(JNIEnv* env, jobject thiz, jbyteArray providedData, jint seedlen, jbyte algo, jbyteArray V_, jint Vlen, jbyteArray Key_, jint Keylen);

#ifdef  __cplusplus
}
#endif

#endif
