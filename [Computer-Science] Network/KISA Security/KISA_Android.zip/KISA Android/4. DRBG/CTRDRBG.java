package kr.or.kisa.seed.ctrdrbg;

import java.util.Arrays;

public class CTRDRBG {
	public static final byte ALGO_SEED = (byte)0x01;
	public static final byte ALGO_ARIA128 = (byte)0x02;
	public static final byte ALGO_ARIA192 = (byte)0x03;
	public static final byte ALGO_ARIA256 = (byte)0x04;
	
	public static final int ALGO_SEED_OUTLEN_IN_BYTES = 16;
	public static final int ALGO_ARIA128_OUTLEN_IN_BYTES = 16;
	public static final int ALGO_ARIA192_OUTLEN_IN_BYTES = 16;
	public static final int ALGO_ARIA256_OUTLEN_IN_BYTES = 16;
	
	public static final int ALGO_SEED_KEYLEN_IN_BYTES = 16;
	public static final int ALGO_ARIA128_KEYLEN_IN_BYTES = 16;
	public static final int ALGO_ARIA192_KEYLEN_IN_BYTES = 24;
	public static final int ALGO_ARIA256_KEYLEN_IN_BYTES = 32;
	
	public static final int ALGO_SEED_SECURITY_STRENGTH_IN_BYTES = 16;
	public static final int ALGO_ARIA128_SECURITY_STRENGTH_IN_BYTES	= 16;
	public static final int ALGO_ARIA192_SECURITY_STRENGTH_IN_BYTES	= 24;
	public static final int ALGO_ARIA256_SECURITY_STRENGTH_IN_BYTES	= 32;
	
	public static final int ALGO_SEED_SEEDLEN_IN_BYTES = ALGO_SEED_OUTLEN_IN_BYTES + ALGO_SEED_KEYLEN_IN_BYTES;
	public static final int ALGO_ARIA128_SEEDLEN_IN_BYTES = ALGO_ARIA128_OUTLEN_IN_BYTES + ALGO_ARIA128_KEYLEN_IN_BYTES;
	public static final int ALGO_ARIA192_SEEDLEN_IN_BYTES = ALGO_ARIA192_OUTLEN_IN_BYTES + ALGO_ARIA192_KEYLEN_IN_BYTES;
	public static final int ALGO_ARIA256_SEEDLEN_IN_BYTES = ALGO_ARIA256_OUTLEN_IN_BYTES + ALGO_ARIA256_KEYLEN_IN_BYTES;
	
	public static final int MAX_V_LEN_IN_BYTES = 16;
	public static final int MAX_Key_LEN_IN_BYTES = 32;
	public static final int MAX_SEEDLEN_IN_BYTES = ALGO_ARIA256_SEEDLEN_IN_BYTES;
	
	public static final long NUM_OF_REQUESTS_BETWEEN_RESEEDS = 0x200000000000L;// 2^48 bits
	
	public static final int STATE_INITIALIZED_FLAG = 0xFE12DC34;
	
	public static final byte NON_DERIVATION_FUNCTION = (byte)0x00;
	public static final byte USE_DERIVATION_FUNCTION = (byte)0xFF;

	private byte		algo; // ARIA or SEED
	private byte[]		V;
	private int 		Vlen;
	private byte[]		Key;
	private int			Keylen;
	private int			seedlen;
	private long		reseed_counter;
	private int			security_strength;
	private int			initialized_flag; // If initialized_flag = STATE_INITIALIZED_FLAG, state is already initialized.
	private byte		derivation_function_flag; // 0x00 : non-df ,  0xFF : use df
	
	public CTRDRBG() {
		this.V = new byte[MAX_V_LEN_IN_BYTES];
		this.Key = new byte[MAX_Key_LEN_IN_BYTES];
	}

	static {
		System.loadLibrary("ctrdrbg");
	}
	
	private native int blockCipherDf(byte algo, byte[] input_string, int len, byte[] output, int outlen);
	private native int update(byte[] provided_data,	int providedlen, byte algo, byte[] V, int Vlen, byte[] Key, int Keylen);
	private native void ctrIncrease(byte[] counter);
	
	public int instantiate(byte algo, byte[] entropy_input, int entropylen, byte[] nonce, int noncelen, byte[] personalization_string, int stringlen, byte derivation_function_flag) {
		byte[] seed_material = new byte[MAX_SEEDLEN_IN_BYTES];
		byte[] seed_material_in = null;
		int seed_material_len = 0;
		int retcode = 0;
		
		if(entropy_input == null) {
			return 0;
		}

		if(derivation_function_flag == USE_DERIVATION_FUNCTION) {
			this.derivation_function_flag = USE_DERIVATION_FUNCTION;
		} else {
			this.derivation_function_flag = NON_DERIVATION_FUNCTION;
		}

		switch(algo) {
			case ALGO_SEED :
				if(derivation_function_flag == USE_DERIVATION_FUNCTION) {
					if(entropylen < ALGO_SEED_SECURITY_STRENGTH_IN_BYTES) {
						return 0;
					}
				} else {
					if(entropylen < ALGO_SEED_SEEDLEN_IN_BYTES) {
						return 0;
					}
				}
				
				if(nonce != null && noncelen < ALGO_SEED_SECURITY_STRENGTH_IN_BYTES / 2) {
					return 0;
				}
				
				this.seedlen = ALGO_SEED_SEEDLEN_IN_BYTES;
				this.Keylen = ALGO_SEED_KEYLEN_IN_BYTES;
				this.Vlen = ALGO_SEED_OUTLEN_IN_BYTES;			
				break;

			case ALGO_ARIA128 :
				if(derivation_function_flag == USE_DERIVATION_FUNCTION) {
					if(entropylen < ALGO_ARIA128_SECURITY_STRENGTH_IN_BYTES) {
						return 0;
					}
				} else {
					if(entropylen < ALGO_ARIA128_SEEDLEN_IN_BYTES) {
						return 0;
					}
				}
				
				if(nonce != null && noncelen < ALGO_ARIA128_SECURITY_STRENGTH_IN_BYTES / 2) {
					return 0;
				}

				this.seedlen = ALGO_ARIA128_SEEDLEN_IN_BYTES;
				this.Keylen = ALGO_ARIA128_KEYLEN_IN_BYTES;
				this.Vlen = ALGO_ARIA128_OUTLEN_IN_BYTES;
				break;
			
			case ALGO_ARIA192 :	
				if(derivation_function_flag == USE_DERIVATION_FUNCTION) {
					if(entropylen < ALGO_ARIA192_SECURITY_STRENGTH_IN_BYTES) {
						return 0;
					}
				} else {
					if(entropylen < ALGO_ARIA192_SEEDLEN_IN_BYTES) {
						return 0;
					}
				}
				
				if(nonce != null && noncelen < ALGO_ARIA192_SECURITY_STRENGTH_IN_BYTES / 2) {
					return 0;
				}
				
				this.seedlen = ALGO_ARIA192_SEEDLEN_IN_BYTES;
				this.Keylen = ALGO_ARIA192_KEYLEN_IN_BYTES;
				this.Vlen = ALGO_ARIA192_OUTLEN_IN_BYTES;
				break;

			case ALGO_ARIA256 :	
				if(derivation_function_flag == USE_DERIVATION_FUNCTION) {
					if(entropylen < ALGO_ARIA256_SECURITY_STRENGTH_IN_BYTES) {
						return 0;
					}
				} else {
					if(entropylen < ALGO_ARIA256_SEEDLEN_IN_BYTES) {
						return 0;
					}
				}
				
				if(nonce != null && noncelen < ALGO_ARIA256_SECURITY_STRENGTH_IN_BYTES / 2) {
					return 0;
				}
				
				this.seedlen = ALGO_ARIA256_SEEDLEN_IN_BYTES;
				this.Keylen = ALGO_ARIA256_KEYLEN_IN_BYTES;
				this.Vlen = ALGO_ARIA256_OUTLEN_IN_BYTES;
				break;

			default :
				return 0; // No Such Algorithm
		}

		this.algo = algo;

		if(this.derivation_function_flag == USE_DERIVATION_FUNCTION) {
			// seed_material = entropy_input || nonce || personalized string
			Arrays.fill(seed_material, (byte)0x00);
			seed_material_len = entropylen;
			
			if(nonce != null && noncelen > 0) {
				seed_material_len += (noncelen);
			}
			
			if(personalization_string != null && stringlen > 0) {
				seed_material_len += (stringlen);
			}
			seed_material_in = new byte[seed_material_len];

			System.arraycopy(entropy_input, 0, seed_material_in, 0, entropylen);
			if(nonce != null && noncelen > 0) {			
				System.arraycopy(nonce, 0, seed_material_in, entropylen, noncelen);
			}
			if(personalization_string != null && stringlen > 0) {
				System.arraycopy(personalization_string, 0, seed_material_in, entropylen + noncelen, stringlen);				
			}
		
			if(this.blockCipherDf(algo, seed_material_in, seed_material_len, seed_material, this.seedlen) == 0) {
				Arrays.fill(seed_material_in, (byte)0x00);
				Arrays.fill(seed_material, (byte)0x00);
				
				return retcode;
			}
		} else {
			int loop = stringlen <= entropylen ? stringlen : entropylen;
			int i;

			if(loop > MAX_SEEDLEN_IN_BYTES) {
				loop = MAX_SEEDLEN_IN_BYTES;
			}
			// seed_material = entropy_input xor personalization_string
			Arrays.fill(seed_material, (byte)0x00);
			if(personalization_string == null || stringlen == 0) {
				for(i = 0; i < entropylen; i++) {
					seed_material[i] = entropy_input[i];
				}
			} else {
				for(i = 0; i < loop; i++) {
					seed_material[i] = (byte)(entropy_input[i] ^ personalization_string[i]);
				}
			}
		}
		
		Arrays.fill(this.Key, (byte)0x00);
		Arrays.fill(this.V, (byte)0x00);

		if(this.update(seed_material, this.seedlen, this.algo, this.V, this.Vlen, this.Key, this.Keylen) == 0) {
			Arrays.fill(seed_material_in, (byte)0x00);
			Arrays.fill(seed_material, (byte)0x00);
			
			return retcode;
		}

		this.reseed_counter = 1;
		
		retcode = 1;
		this.initialized_flag = STATE_INITIALIZED_FLAG;
		
		return retcode;
	}
	
	public int reSeed(byte[] entropy_input, int entropylen, byte[] additional_input, int addlen) {
		byte[] seed_material = new byte[MAX_SEEDLEN_IN_BYTES];
		byte[] seed_material_in = null;
		int seed_material_len = 0;
		int retcode = 0;
			
		if(entropy_input == null) {
			return 0;
		}

		if(addlen > this.seedlen) {
			addlen = this.seedlen;
		}

		if(this.initialized_flag != STATE_INITIALIZED_FLAG) {
			return 0; // KISA_CTR_DRBG_Instantiate(...) required
		}

		switch(this.algo) {			
			case ALGO_SEED :
				if(entropylen < ALGO_SEED_SECURITY_STRENGTH_IN_BYTES) {
					return 0;
				}
				
				break;

			case ALGO_ARIA128 :
				if(entropylen < ALGO_ARIA128_SECURITY_STRENGTH_IN_BYTES) {
					return 0;
				}
				
				break;
			
			case ALGO_ARIA192 :	
				if(entropylen < ALGO_ARIA192_SECURITY_STRENGTH_IN_BYTES) {
					return 0;
				}
				
				break;

			case ALGO_ARIA256 :	
				if(entropylen < ALGO_ARIA256_SECURITY_STRENGTH_IN_BYTES) {
					return 0;
				}
				
				break;

			default :
				return 0; // No Such Algorithm
		}

		if(this.derivation_function_flag == USE_DERIVATION_FUNCTION) {
			Arrays.fill(seed_material, (byte)0x00);
			seed_material_len = entropylen;
			if(addlen > 0) {
				seed_material_len += (addlen);
			}
			seed_material_in = new byte[seed_material_len];

			System.arraycopy(entropy_input, 0, seed_material_in, 0, entropylen);
			if(addlen > 0) {
				System.arraycopy(additional_input, 0, seed_material_in, entropylen, addlen);
			}

			if(this.blockCipherDf(this.algo, seed_material_in, seed_material_len, seed_material, this.seedlen) == 0) {
				Arrays.fill(seed_material_in, (byte)0x00);
				Arrays.fill(seed_material, (byte)0x00);
				
				return retcode;
			}
		} else {
			int loop = addlen <= entropylen ? addlen : entropylen;
			int i;

			Arrays.fill(seed_material, (byte)0x00);
			// seed_material = entropy_input xor additional_input
			if(additional_input == null || addlen == 0) {
				for(i = 0; i < entropylen; i++) {
					seed_material[i] = entropy_input[i];
				}
			} else {
				for(i = 0; i < loop; i++) {
					seed_material[i] = (byte)(entropy_input[i] ^ additional_input[i]);
				}
			}
		}
		
		if(this.update(seed_material, this.seedlen, this.algo, this.V, this.Vlen, this.Key, this.Keylen) == 0) {
			Arrays.fill(seed_material_in, (byte)0x00);
			Arrays.fill(seed_material, (byte)0x00);
			
			return retcode;
		}

		this.reseed_counter = 1;
		
		retcode = 1;
		
		return retcode;
	}
	
	public int generate(byte[] output, int requested_num_of_bits, byte[] addtional_input, int addlen) {
		int[] seed_key = new int[32];
		byte[] aria_key = new byte[16 * (16 + 1)];
		int[] rounds = new int[1];
		byte[] addtional_input_for_seed = new byte[MAX_SEEDLEN_IN_BYTES];
		int request_num_of_bytes;
		int ptr = 0;

		int retcode = 0;
		byte[] temp = null;
		int templen = 0;

		if(addlen > this.seedlen) {
			addlen = this.seedlen;
		}

		if(requested_num_of_bits <= 0) {
			return 0; // No length to generate
		} else {
			request_num_of_bytes = requested_num_of_bits / 8 + ((requested_num_of_bits % 8) != 0 ? 1 : 0);
		}

		if(this.reseed_counter > NUM_OF_REQUESTS_BETWEEN_RESEEDS) {
			return 0; // Reseed Required.
		}

		if(addtional_input != null && addlen > 0) {
			if(this.derivation_function_flag == USE_DERIVATION_FUNCTION) {
				if(this.blockCipherDf(this.algo, addtional_input, addlen, addtional_input_for_seed, this.seedlen) == 0) {
					Arrays.fill(addtional_input_for_seed, (byte)0x00);

					return 0;
				}

				if(this.update(addtional_input_for_seed, this.seedlen, this.algo, this.V, this.Vlen, this.Key, this.Keylen) == 0) {
					Arrays.fill(addtional_input_for_seed, (byte)0x00);

					return 0;
				}
			} else {
				Arrays.fill(addtional_input_for_seed, (byte)0x00);
				System.arraycopy(addtional_input, 0, addtional_input_for_seed, 0, addlen);

				if(this.update(addtional_input_for_seed, this.seedlen, this.algo, this.V, this.Vlen, this.Key, this.Keylen) == 0) {
					Arrays.fill(addtional_input_for_seed, (byte)0x00);

					return 0;
				}
			}
		} else {
			Arrays.fill(addtional_input_for_seed, (byte)0x00);
		}

		templen = request_num_of_bytes + (MAX_V_LEN_IN_BYTES - (request_num_of_bytes % MAX_V_LEN_IN_BYTES));
		temp = new byte[templen];
		templen = 0;

		switch(this.algo) {
			case ALGO_SEED :
				SEEDCBC.seedCBCInit(this.Key, seed_key);
				while(templen < request_num_of_bytes) {
					this.ctrIncrease(this.V);
					SEEDCBC.encryptBlock(this.V, temp, ptr, seed_key);
					ptr += ALGO_SEED_OUTLEN_IN_BYTES;
					templen += ALGO_SEED_OUTLEN_IN_BYTES;
				}
				Arrays.fill(seed_key, (byte)0x00);
				break;

			case ALGO_ARIA128 :
				ARIACBC.ariaEncryptInit(this.Key, 128, aria_key, rounds);
				while(templen < request_num_of_bytes) {
					this.ctrIncrease(this.V);
					ARIACBC.processBlock(this.V, rounds[0], aria_key, temp, ptr);
					ptr += ALGO_ARIA128_OUTLEN_IN_BYTES;
					templen += ALGO_ARIA128_OUTLEN_IN_BYTES;
				}
				Arrays.fill(aria_key, (byte)0x00);
				break;

			case ALGO_ARIA192 :
				ARIACBC.ariaEncryptInit(this.Key, 192, aria_key, rounds);
				while(templen < request_num_of_bytes) {
					this.ctrIncrease(this.V);
					ARIACBC.processBlock(this.V, rounds[0], aria_key, temp, ptr);
					ptr += ALGO_ARIA192_OUTLEN_IN_BYTES;
					templen += ALGO_ARIA192_OUTLEN_IN_BYTES;
				}
				Arrays.fill(aria_key, (byte)0x00);
				break;

			case ALGO_ARIA256 :
				ARIACBC.ariaEncryptInit(this.Key, 256, aria_key, rounds);
				while(templen < request_num_of_bytes) {
					this.ctrIncrease(this.V);
					ARIACBC.processBlock(this.V, rounds[0], aria_key, temp, ptr);
					ptr += ALGO_ARIA256_OUTLEN_IN_BYTES;
					templen += ALGO_ARIA256_OUTLEN_IN_BYTES;
				}
				Arrays.fill(aria_key, (byte)0x00);
				break;
		}
		System.arraycopy(temp, 0, output, 0, request_num_of_bytes);

		if(requested_num_of_bits % 8 != 0) {
			output[request_num_of_bytes - 1] = (byte)(temp[request_num_of_bytes - 1] & (0x000000FF & (0xFF << (8-(requested_num_of_bits % 8)))));
		}

		if(this.update(addtional_input_for_seed, this.seedlen, this.algo, this.V, this.Vlen, this.Key, this.Keylen) == 0) {
			Arrays.fill(temp, (byte)0x00);
			Arrays.fill(addtional_input_for_seed, (byte)0x00);

			return retcode;
		}

		(this.reseed_counter)++;

		retcode = 1;

		return retcode;
	}
}