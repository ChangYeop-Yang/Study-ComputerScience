package kr.or.kisa.seed.eckcdsa;

public class ECC_POINT {
    GFP_ECPT_AC pfield_point;
    GF2N_ECPT_AC c2field_point;

    ECC_POINT(){
        pfield_point = new GFP_ECPT_AC();
        c2field_point = new GF2N_ECPT_AC();
    }
}
