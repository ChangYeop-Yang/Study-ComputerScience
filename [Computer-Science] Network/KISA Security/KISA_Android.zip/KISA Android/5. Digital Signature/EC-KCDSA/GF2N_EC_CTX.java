package kr.or.kisa.seed.eckcdsa;

public class GF2N_EC_CTX {
    IRR irr;
    int[] a2;
    int[] a6;

    GF2N_EC_CTX(){
        irr = new IRR();
        a2 = new int[501];
        a6 = new int[501];
    }
}
