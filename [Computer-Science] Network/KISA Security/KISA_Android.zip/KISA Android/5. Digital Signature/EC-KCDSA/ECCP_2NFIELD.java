package kr.or.kisa.seed.eckcdsa;

public class ECCP_2NFIELD {
    GF2N_EC_CTX curve;
    GF2N_ECPT_AC base;

    ECCP_2NFIELD(){
        curve = new GF2N_EC_CTX();
        base = new GF2N_ECPT_AC();
    }
}
