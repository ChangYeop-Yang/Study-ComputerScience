package kr.or.kisa.seed.eckcdsa;

public class GFP_EC_CTX {
    MPZ prime;
    MPZ a;
    MPZ b;

    GFP_EC_CTX(){
        prime = new MPZ();
        a = new MPZ();
        b = new MPZ();
    }
}
