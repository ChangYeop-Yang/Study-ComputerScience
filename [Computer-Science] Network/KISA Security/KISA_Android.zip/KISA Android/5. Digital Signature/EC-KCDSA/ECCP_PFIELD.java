package kr.or.kisa.seed.eckcdsa;

public class ECCP_PFIELD {
    GFP_EC_CTX curve;
    GFP_ECPT_AC base;
    ECCP_PFIELD() {
        curve = new GFP_EC_CTX();
        base = new GFP_ECPT_AC();
    }
}
