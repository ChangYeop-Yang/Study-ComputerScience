package kr.or.kisa.seed.hightcbc;

public class HIGHTCBC {
    public static final int HIGHT_BLOCK_SIZE = 8;

    public static final int ENC = 1;
    public static final int DEC = 0;

    private int encrypt;
    private byte[] ivec;
    private KISA_HIGHT_KEY hight_key;
    private byte[] cbc_buffer;
    private int buffer_length;
    private byte[] cbc_last_block;
    private int last_block_flag;

    private class KISA_HIGHT_KEY {
        private byte[] user_key;
        private byte[] key_data;

        public KISA_HIGHT_KEY() {
            user_key = new byte[16];
            key_data = new byte[128];
        }
    }
    static {
        System.loadLibrary("hightcbc");
    }
    public HIGHTCBC() {
        this.ivec = new byte[HIGHT_BLOCK_SIZE];
        this.hight_key = new KISA_HIGHT_KEY();
        this.cbc_buffer = new byte[HIGHT_BLOCK_SIZE];
        this.cbc_last_block = new byte[HIGHT_BLOCK_SIZE];
    }

    private native void hightCBCInit(byte[] key, byte[] user_key, byte[] key_data);
    private native int hightCBCProcess(int enc, int[] intValueArray, byte[] user_key, byte[] key_data, byte[] ivec,
                                       byte[] cbc_buffer, byte[] cbc_last_block, byte[] inputText, int inputOffset, int inputTextLen, byte[] outputText, int outputOffset);
    private native void hightCBCClose(int enc, byte[] user_key, byte[] key_data, byte[] ivec, byte[] cbc_buffer,
                                      byte[] outputText, int outputTextLen);

    public int init(int enc, byte[] key, byte[] iv) {
        if(key == null || iv == null) {
            return 0;
        }

        this.encrypt = enc;
        this.ivec = Utils.subBytes(iv, 0, HIGHT_BLOCK_SIZE - 1);
        hightCBCInit(key, this.hight_key.user_key, this.hight_key.key_data);
        this.buffer_length = 0;
        this.last_block_flag = 0;

        return 1;
    }

    public int process(byte[] inputText, int inputOffset, int inputTextLen, byte[] outputText, int outputOffset) {
        if(inputText == null || outputText == null) {
            return 0;
        }

        if(inputTextLen <= 0) {
            return -1;
        }

        if(outputOffset < 0 || outputOffset >= outputText.length) {
            return -1;
        }

        int outputTextLen = 0;

        int[] intValueArray = {
                this.buffer_length, this.last_block_flag
        };

        if(this.encrypt == ENC) {
            outputTextLen = hightCBCProcess(this.encrypt, intValueArray, this.hight_key.user_key, this.hight_key.key_data,
                    this.ivec, this.cbc_buffer, this.cbc_last_block, inputText, inputOffset, inputTextLen, outputText, outputOffset);
        } else {
            outputTextLen = hightCBCProcess(this.encrypt, intValueArray, this.hight_key.user_key, this.hight_key.key_data,
                    this.ivec, this.cbc_buffer, this.cbc_last_block, inputText, inputOffset, inputTextLen, outputText, outputOffset);
            this.last_block_flag = intValueArray[1];
        }
        this.buffer_length = intValueArray[0];

        return outputTextLen;
    }

    public int close(byte[] outputText, int outputTextLen) {
        if(outputText == null) {
            return 0;
        }

        int padLen = 0, i;

        if(this.encrypt == ENC) {
            padLen = HIGHT_BLOCK_SIZE - (this.buffer_length);

            for(i = this.buffer_length; i < HIGHT_BLOCK_SIZE; i++) {
                this.cbc_buffer[i] = (byte)padLen;
            }

            hightCBCClose(this.encrypt, this.hight_key.user_key, this.hight_key.key_data, this.ivec, this.cbc_buffer, outputText, outputTextLen);

            outputTextLen = HIGHT_BLOCK_SIZE;
        } else {
            padLen = HIGHT_BLOCK_SIZE - this.cbc_last_block[HIGHT_BLOCK_SIZE - 1];

            if(padLen > HIGHT_BLOCK_SIZE) {
                return -1;
            }

            if(padLen > 1) {
                i = this.cbc_last_block[HIGHT_BLOCK_SIZE - 1];

                while(i > 0) {
                    if(this.cbc_last_block[HIGHT_BLOCK_SIZE - 1] != this.cbc_last_block[HIGHT_BLOCK_SIZE - i]) {
                        return -1;
                    }

                    i--;
                }
            }

            for(i = 0; i < padLen; i++) {
                outputText[outputTextLen + i] = this.cbc_last_block[i];
            }

            outputTextLen = padLen;
        }

        this.buffer_length = this.last_block_flag = 0;

        return outputTextLen;
    }

    public int CBC_ENCRYPT(byte[] user_key, byte[] iv, byte[] inputText, int inputOffset, int inputTextLen, byte[] outputText, int outputOffset) {
        int padLen = 0;
        int outputTextLen = 0;

        if(this.init(ENC, user_key, iv) == 0)
        {
            return 0;
        }

        outputTextLen = this.process(inputText, inputOffset, inputTextLen, outputText, outputOffset);
        if(outputTextLen < 0)
        {
            return 0;
        }

        padLen = this.close(outputText, outputTextLen);
        if(padLen < 0)
        {
            return 0;
        }

        return outputTextLen + padLen;
    }

    public int CBC_DECRYPT(byte[] user_key, byte[] iv, byte[] inputText, int inputOffset, int inputTextLen, byte[] outputText, int outputOffset) {
        int padLen = 0;
        int outputTextLen = 0;

        if(this.init(DEC, user_key, iv) == 0)
        {
            return 0;
        }

        outputTextLen = this.process(inputText, inputOffset, inputTextLen, outputText, outputOffset);
        if(outputTextLen < 0)
        {
            return 0;
        }

        padLen = this.close(outputText, outputTextLen);
        if(padLen < 0)
        {
            return 0;
        }

        return outputTextLen + padLen;
    }

    public int getOutputSize(int inputLen) {
        return this.getOutputSize(this.encrypt, inputLen);
    }

    public int getOutputSize(int enc, int inputLen) {
        int outputLen = 0, padLen;

        if(enc == ENC) {
            padLen = HIGHT_BLOCK_SIZE - inputLen % HIGHT_BLOCK_SIZE;
            if(padLen == HIGHT_BLOCK_SIZE) {
                outputLen = inputLen + HIGHT_BLOCK_SIZE;
            } else {
                outputLen = inputLen + padLen;
            }
        } else {
            outputLen = inputLen;
        }

        return outputLen ;
    }
}