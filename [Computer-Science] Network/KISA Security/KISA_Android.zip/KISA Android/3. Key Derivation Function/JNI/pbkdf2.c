#include <jni.h>

#include <stdio.h>
#include <malloc.h>
#include <string.h>
#include "sha256.h"

#define MAX_HMAC_BLOCK 128
#define IPAD 0x36
#define OPAD 0x5C

typedef struct hmac_unit_structure
{
    KISA_SHA256 sha1_unit;
    KISA_SHA256 state_i;
    KISA_SHA256 state_o;
    unsigned int state_length;
    unsigned char key[128];
    int key_length;
    int hmac_status;
} HMAC_ST;

HMAC_ST *HMAC_SHA256_new(void);
void HMAC_SHA256_clear(HMAC_ST *unit);
void HMAC_SHA256_free(HMAC_ST *unit);

int HMAC_SHA256_init(HMAC_ST *unit, unsigned char *key, int keyLen);
int HMAC_SHA256_update(HMAC_ST *unit, const unsigned char *input, int inLength);
int HMAC_SHA256_final(HMAC_ST *unit, unsigned char *output);

int HMAC_SHA256(unsigned char *key, int keyLen, const unsigned char *input, int inLength, unsigned char *output);

#define PUT64(n) n##ULL

#define MIN(x, y) ( ((x)<(y))?(x):(y) )

#define ROLc(x, y) ((((unsigned int)(x)<<(unsigned int)((y)&31)) | (((unsigned int)(x)&0xFFFFFFFFU)>>(unsigned int)(32-((y)&31)))) & 0xFFFFFFFFU)
#define RORc(x, y) (((((unsigned int)(x)&0xFFFFFFFFU)>>(unsigned int)((y)&31)) | ((unsigned int)(x)<<(unsigned int)(32-((y)&31)))) & 0xFFFFFFFFU)

#define OR(x,y)			(x|y)
#define AND(x,y)		(x&y)
#define XOR(x,y)		(x^y)

#define S(x, n)         RORc((x),(n))
#define R(x, n)         ((uint64_t)((x)>>(n)))

#define SHR(x, n)   \
	((((x)>>((uint64_t)((n)&PUT64(63)))) | \
	((x)<<((uint64_t)(64-((n)&PUT64(63)))))))

#define ROTR(x, n)         (((uint64_t))((x)>>n))

#define WORK_VAR(a,b,c,d,e,f,g,h,i)                    \
	t0 = h + (SHR(e, 14) ^ SHR(e, 18) ^ SHR(e, 41)) + F(e, f, g) + K_512[i] + W[i];   \
	t1 = (SHR(a, 28) ^ SHR(a, 34) ^ SHR(a, 39)) + H(a, b, c);                  \
	d += t0; \
	h  = t0 + t1;

#define F(x,y,z)		(XOR(z,(AND(x,(XOR(y,z))))))
#define G(x,y,z)		(XOR(x,XOR(y,z)))
#define H(x,y,z)		(OR(AND(x,y),AND(z,OR(x,y))))

#define SHA256_BLOCK_SIZEx8		512

static const uint32_t SHA256_K[64] = {
        0x428a2f98UL, 0x71374491UL, 0xb5c0fbcfUL, 0xe9b5dba5UL, 0x3956c25bUL,
        0x59f111f1UL, 0x923f82a4UL, 0xab1c5ed5UL, 0xd807aa98UL, 0x12835b01UL,
        0x243185beUL, 0x550c7dc3UL, 0x72be5d74UL, 0x80deb1feUL, 0x9bdc06a7UL,
        0xc19bf174UL, 0xe49b69c1UL, 0xefbe4786UL, 0x0fc19dc6UL, 0x240ca1ccUL,
        0x2de92c6fUL, 0x4a7484aaUL, 0x5cb0a9dcUL, 0x76f988daUL, 0x983e5152UL,
        0xa831c66dUL, 0xb00327c8UL, 0xbf597fc7UL, 0xc6e00bf3UL, 0xd5a79147UL,
        0x06ca6351UL, 0x14292967UL, 0x27b70a85UL, 0x2e1b2138UL, 0x4d2c6dfcUL,
        0x53380d13UL, 0x650a7354UL, 0x766a0abbUL, 0x81c2c92eUL, 0x92722c85UL,
        0xa2bfe8a1UL, 0xa81a664bUL, 0xc24b8b70UL, 0xc76c51a3UL, 0xd192e819UL,
        0xd6990624UL, 0xf40e3585UL, 0x106aa070UL, 0x19a4c116UL, 0x1e376c08UL,
        0x2748774cUL, 0x34b0bcb5UL, 0x391c0cb3UL, 0x4ed8aa4aUL, 0x5b9cca4fUL,
        0x682e6ff3UL, 0x748f82eeUL, 0x78a5636fUL, 0x84c87814UL, 0x8cc70208UL,
        0x90befffaUL, 0xa4506cebUL, 0xbef9a3f7UL, 0xc67178f2UL
};


static int SHA256_compute(KISA_SHA256 *sha256, uint8_t *data);

int KISA_SHA256_init(KISA_SHA256 *sha256) {

    if(sha256 == NULL)
        return 0;

    sha256->l1 = 0;
    sha256->l2 = 0;
    sha256->data[0] = 0x6A09E667UL;
    sha256->data[1] = 0xBB67AE85UL;
    sha256->data[2] = 0x3C6EF372UL;
    sha256->data[3] = 0xA54FF53AUL;
    sha256->data[4] = 0x510E527FUL;
    sha256->data[5] = 0x9B05688CUL;
    sha256->data[6] = 0x1F83D9ABUL;
    sha256->data[7] = 0x5BE0CD19UL;

    return 1;
}

int KISA_SHA256_update(KISA_SHA256 *sha256, const uint8_t *data, uint32_t length) {

    uint32_t n;

    if (sha256->l2 > SHA256_BLOCK_SIZE)
        return 0;

    while (length > 0) {

        if (!sha256->l2 && length >= SHA256_BLOCK_SIZE) {

            if (!(SHA256_compute(sha256, (uint8_t *)data)))
                return 0;

            sha256->l1 += SHA256_BLOCK_SIZEx8;
            data += SHA256_BLOCK_SIZE;
            length -= SHA256_BLOCK_SIZE;

        } else {

            n = MIN((SHA256_BLOCK_SIZE - sha256->l2), length);
            memcpy(sha256->buf + sha256->l2, data, n);
            data += n;
            sha256->l2 += n;
            length -= n;

            if (sha256->l2 == SHA256_BLOCK_SIZE) {
                if (!(SHA256_compute(sha256, sha256->buf)))
                    return 0;

                sha256->l2 = 0;
                sha256->l1 += SHA256_BLOCK_SIZEx8;
            }
        }
    }
    return 1;
}

int KISA_SHA256_final(KISA_SHA256 *sha256, uint8_t *out) {

    int i;
    int off = 0;

    if(sha256->l2 >= SHA256_BLOCK_SIZE)
        return 0;


    sha256->l1 += sha256->l2 << 3;
    sha256->buf[sha256->l2++] = (uint8_t)0x80;

    if(sha256->l2 > 56) {
        memset(sha256->buf+sha256->l2, 0, 64 - (sha256->l2));
        sha256->l2 = SHA256_BLOCK_SIZE;
        SHA256_compute(sha256, sha256->buf);
        sha256->l2 = 0;
    }

    while(sha256->l2 < 56)
        sha256->buf[sha256->l2++] = 0;

    sha256->buf[56] = (uint8_t)(sha256->l1>>56);
    sha256->buf[57] = (uint8_t)(sha256->l1>>48);
    sha256->buf[58] = (uint8_t)(sha256->l1>>40);
    sha256->buf[59] = (uint8_t)(sha256->l1>>32);
    sha256->buf[60] = (uint8_t)(sha256->l1>>24);
    sha256->buf[61] = (uint8_t)(sha256->l1>>16);
    sha256->buf[62] = (uint8_t)(sha256->l1>>8);
    sha256->buf[63] = (uint8_t)(sha256->l1);

    SHA256_compute(sha256, sha256->buf);

    for(i = 0; i < 8; i++) {
        off = i << 2;
        (out+off)[3] = (uint8_t)(sha256->data[i]);
        (out+off)[2] = (uint8_t)(sha256->data[i]>>8);
        (out+off)[1] = (uint8_t)(sha256->data[i]>>16);
        (out+off)[0] = (uint8_t)(sha256->data[i]>>24);
    }
    return 1;
}

static int SHA256_compute(KISA_SHA256 *sha256, uint8_t *data) {

    int i;
    uint32_t data_temp[8], W[64];
    uint32_t temp, t1, temp2;
    int off = 0;

    data_temp[0] = sha256->data[0];
    data_temp[1] = sha256->data[1];
    data_temp[2] = sha256->data[2];
    data_temp[3] = sha256->data[3];
    data_temp[4] = sha256->data[4];
    data_temp[5] = sha256->data[5];
    data_temp[6] = sha256->data[6];
    data_temp[7] = sha256->data[7];

    for(i = 0; i < 16; i++) {
        off = i<<2;
        W[i] = (((uint32_t)((data+off)[0]<<24)) |
                ((uint32_t)((data+off)[1]<<16)) |
                ((uint32_t)((data+off)[2]<<8))  |
                ((uint32_t)((data+off)[3])));
    }

    for(i = 16; i < 64; i++)
        W[i] = (S(W[i - 2], 17) ^ S(W[i - 2], 19) ^ R(W[i - 2], 10)) +
               W[i - 7] + (S(W[i - 15], 7) ^ S(W[i - 15], 18) ^ R(W[i - 15], 3)) + W[i - 16];

    for(i = 0; i < 64; ++i) {
        t1 = data_temp[7] + (S(data_temp[4], 6) ^ S(data_temp[4], 11) ^ S(data_temp[4], 25))
             + F(data_temp[4], data_temp[5], data_temp[6]) + SHA256_K[i] + W[i];
        temp2 = (S(data_temp[0], 2) ^ S(data_temp[0], 13) ^ S(data_temp[0], 22))
                + H(data_temp[0], data_temp[1], data_temp[2]);
        data_temp[3] += t1;
        data_temp[7] = t1 + temp2;

        temp = data_temp[7];
        data_temp[7] = data_temp[6];
        data_temp[6] = data_temp[5];
        data_temp[5] = data_temp[4];
        data_temp[4] = data_temp[3];
        data_temp[3] = data_temp[2];
        data_temp[2] = data_temp[1];
        data_temp[1] = data_temp[0];
        data_temp[0] = temp;
    }

    sha256->data[0] += data_temp[0];
    sha256->data[1] += data_temp[1];
    sha256->data[2] += data_temp[2];
    sha256->data[3] += data_temp[3];
    sha256->data[4] += data_temp[4];
    sha256->data[5] += data_temp[5];
    sha256->data[6] += data_temp[6];
    sha256->data[7] += data_temp[7];

    return 1;
}


HMAC_ST *HMAC_SHA256_new(void)
{
    HMAC_ST *unit = (HMAC_ST*)malloc(sizeof *unit);

    if(unit == NULL) {
        return NULL;
    }

    if (unit)
        memset(unit,0,sizeof(HMAC_ST));
    return unit;
}

void HMAC_SHA256_clear(HMAC_ST *unit)
{

    if(unit->state_length != 0)
    {
        memset(&(unit->state_i),0x00,sizeof(unit->state_i));
        memset(&(unit->state_o),0x00,sizeof(unit->state_o));
    }
}

void HMAC_SHA256_free(HMAC_ST *unit)
{
    if (unit)
    {
        HMAC_SHA256_clear(unit);
        free(unit);
    }
}

int HMAC_SHA256_init(HMAC_ST *unit, unsigned char *key, int keyLen)
{
    int i,block;
    int retcode = 0;
    unsigned char pad[MAX_HMAC_BLOCK];

    int statesize = sizeof(KISA_SHA256);

    HMAC_SHA256_clear(unit);

    unit->hmac_status = 1;

    if ((retcode = KISA_SHA256_init(&(unit->sha1_unit))) != 1) {
        return retcode;
    }

    unit->state_length = statesize;

    if (key == NULL)
    {
        return 0;
    }
    block = SHA256_BLOCK_SIZE;

    if(!(block <= (int)sizeof(unit->key)))
    {
        return 0;
    }

    if (block < keyLen)
    {
        if((retcode = KISA_SHA256_update(&(unit->sha1_unit),key,keyLen)) != 1)
        {
            return retcode;
        }
        if((retcode = KISA_SHA256_final(&(unit->sha1_unit),unit->key)) != 1)
        {
            return retcode;
        }
        unit->key_length = SHA256_DIGEST_LENGTH;
        KISA_SHA256_init(&(unit->sha1_unit));
    }
    else
    {
        if(!(keyLen>=0 && keyLen<=(int)sizeof(unit->key)))
        {
            return 0;
        }
        memcpy(unit->key,key,keyLen);
        unit->key_length = keyLen;
    }

    if(unit->key_length < block)
        memset(&unit->key[unit->key_length], 0x00, block - unit->key_length);

    for (i=0; i<MAX_HMAC_BLOCK; i++) pad[i] = OPAD ^ unit->key[i];

    if(KISA_SHA256_update(&(unit->sha1_unit), pad, SHA256_BLOCK_SIZE) != 1)
    {
        return 0;
    }
    memcpy(&(unit->state_o), &(unit->sha1_unit), statesize);

    for (i=0; i<MAX_HMAC_BLOCK; i++) pad[i] = IPAD ^ unit->key[i];

    //unit->md_unit->init(unit->md_unit->state);
    KISA_SHA256_init(&(unit->sha1_unit));

    if((retcode = KISA_SHA256_update(&(unit->sha1_unit), pad, SHA256_BLOCK_SIZE)) != 1)
    {
        return retcode;
    }

    memcpy(&(unit->state_i), &(unit->sha1_unit), statesize);

    return 1;
}

int HMAC_SHA256_update(HMAC_ST *unit, const unsigned char *input, int inLength)
{
    if(unit->hmac_status == 3)
    {
        memcpy(&(unit->sha1_unit), &(unit->state_i), sizeof(KISA_SHA256));
        unit->hmac_status = 1;
    }
    if(KISA_SHA256_update(&(unit->sha1_unit), input, inLength) != 1)
    {
        return 0;
    }
    unit->hmac_status = 2;
    return 1;
}

int HMAC_SHA256_final(HMAC_ST *unit, unsigned char *output)
{
    int i = SHA256_DIGEST_LENGTH;
    unsigned char buf[128];

    if(KISA_SHA256_final(&(unit->sha1_unit), buf) != 1)
    {
        return 0;
    }
    KISA_SHA256_init(&(unit->sha1_unit));

    memcpy(&(unit->sha1_unit), &(unit->state_o), sizeof(KISA_SHA256));

    if(KISA_SHA256_update(&(unit->sha1_unit), buf, i) != 1)
    {
        return 0;
    }

    if(KISA_SHA256_final(&(unit->sha1_unit), output) != 1)
    {
        return 0;
    }
    unit->hmac_status = 3;
    return 1;
}

int HMAC_SHA256(unsigned char *key, int keyLen, const unsigned char *input, int inLength,
                unsigned char *output)
{
    HMAC_ST *unit = HMAC_SHA256_new();

    if(HMAC_SHA256_init(unit,key,keyLen) != 1)
    {
        HMAC_SHA256_free(unit);
        return 0;
    }

    if(HMAC_SHA256_update(unit,input,inLength) != 1)
    {
        HMAC_SHA256_free(unit);
        return 0;
    }

    if(HMAC_SHA256_final(unit,output) != 1)
    {
        HMAC_SHA256_free(unit);
        return 0;
    }

    HMAC_SHA256_free(unit);

    return 1;
}



JNIEXPORT jint JNICALL
Java_kr_or_kisa_seed_pbkdf2_PBKDF2_pbkdf2(JNIEnv *env, jobject instance, jbyteArray password_,
                                        jint passwordLen, jbyteArray salt, jint saltLen, jint iter,
                                        jbyteArray key, jint keyLen) {
    jbyte *pPassword = (*env)->GetByteArrayElements(env, password_, NULL);
    jbyte *pSalt = (*env)->GetByteArrayElements(env, salt, NULL);
    jbyte *pKey = (*env)->GetByteArrayElements(env, key, NULL);

    unsigned char* salt_and_int = NULL;
    int saltIntLen;
    unsigned char U[64]; // Max Digest Size
    int ULen = SHA256_DIGEST_LENGTH;
    unsigned char T[64]; // Max Digest Size
    int l,r,hLen = SHA256_DIGEST_LENGTH, outInd = 0;
    int i,j,k, retcode = 0;

    HMAC_ST* hmac = NULL;

    l = keyLen / hLen + (keyLen%hLen == 0 ? 0 : 1);
    r = keyLen - ((l-1)*hLen);

    if(r < 0)
        return 0;

    salt_and_int = (unsigned char*)malloc(saltLen+4);

    if (salt_and_int == NULL)	goto ret;

    memcpy(salt_and_int,pSalt,saltLen);

    hmac = HMAC_SHA256_new();

    for(i=1;i <= l;i++)
    {
        saltIntLen = saltLen+4;

        salt_and_int[saltLen    ] = (i >> 24) & 0xFF;
        salt_and_int[saltLen + 1] = (i >> 16) & 0xFF;
        salt_and_int[saltLen + 2] = (i >> 8 ) & 0xFF;
        salt_and_int[saltLen + 3] = (i      ) & 0xFF;

        retcode = HMAC_SHA256_init(hmac,pPassword,passwordLen);
        if(retcode != 1) goto ret;
        retcode = HMAC_SHA256_update(hmac,salt_and_int,saltIntLen);
        if(retcode != 1) goto ret;
        retcode = HMAC_SHA256_final(hmac,U);
        if(retcode != 1) goto ret;
        memset(T, 0x00, 64);

        for(k=0;k<ULen;k++) T[k] ^= U[k];

        for(j=1;j<iter;j++)
        {
            retcode = HMAC_SHA256_init(hmac,pPassword,passwordLen);
            if(retcode != 1) goto ret;
            retcode = HMAC_SHA256_update(hmac,U,ULen);
            if(retcode != 1) goto ret;
            retcode = HMAC_SHA256_final(hmac,U);
            if(retcode != 1) goto ret;
            for(k=0;k<ULen;k++) T[k] ^= U[k];
        }
        memcpy(pKey + (outInd),T,(i == l)?r:ULen);
        outInd += (i==l)?r:ULen;
    }

    retcode = 1;

    ret:
    if(salt_and_int) free(salt_and_int);

    if(hmac) HMAC_SHA256_free(hmac);



    (*env)->ReleaseByteArrayElements(env, password_, pPassword, 0);
    (*env)->ReleaseByteArrayElements(env, salt, pSalt, 0);
    (*env)->ReleaseByteArrayElements(env, key, pKey, 0);

    return retcode;
}




